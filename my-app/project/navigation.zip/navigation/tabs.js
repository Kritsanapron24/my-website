import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';


import Home from '../screen/Home';
import Profile from '../screen/profile'


const Tab = createBottomTabNavigator();


const Tabs = ({ navigation }) =>{
  return(
    <Tab.Navigator
    tabBarOptions={{
      activeTintColor: '#A7D397',
      labelStyle: {
        fontSize: 16, 
      },
    }}
  >
    <Tab.Screen
      name="หน้าหลัก"
      component={Home}
      options={{
        headerShown: false,
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="home" color={color} size={size} />
        ),
      }}
    />
    <Tab.Screen
      name="โปรไฟล์"
      component={Profile}
      options={{
        headerShown: false,
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="account" color={color} size={size} />
        ),
      }}
    />
  </Tab.Navigator>
  );
}



export default Tabs;


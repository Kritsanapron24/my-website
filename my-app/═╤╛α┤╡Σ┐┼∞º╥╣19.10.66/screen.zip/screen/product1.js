import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const Product1 = () => {
  const [heartClicked, setHeartClicked] = useState(false);
  const navigation = useNavigation(); 

  const handleHeartClick = () => {
    setHeartClicked(!heartClicked);
  };

  return (
    <View style={styles.container}>
      <View style={styles.head}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons
            name="arrow-back-outline"
            size={30}
            color="dimgray"
            style={{
              padding: 3,
              marginTop: 15,
            }}
          />
        </TouchableOpacity>
        
      </View>
      <View style={styles.header}>
      <Image source={{ uri: "https://storage.naiin.com/system/application/bookstore/resource/product/202309/589860/1000264794_front_XXXL.jpg?imgname=สักวันชีวิตของเธอจะผลิบานและงดงามจนใจเต้นรัว", }}
            style={{ width: 200, height: 310, borderRadius: 10,borderColor: 'white',
            borderWidth: 3,}} />
      </View>

      <View style={styles.content}>
        <Text style={styles.profileName}>สักวันชีวิตของเธอจะผลิบานและงดงาม</Text>
        <Text style={styles.price}>฿210.75</Text>
        <View style={styles.type}>
          <View style={styles.typebox}>
            <Text style={styles.typetext}>ปกแข็ง</Text>
          </View>
          <View style={styles.typebox}>
            <Text style={styles.typetext}>ปกอ่อน</Text>
          </View>
          <View style={styles.typebox}>
            <Text style={styles.typetext}>มือ 1</Text>
          </View>
          <View style={styles.typebox}>
            <Text style={styles.typetext}>มือ 2</Text>
          </View>
        </View>
        <View style={styles.detail}>
          <Text style={styles.textdetail}>
          เราทุกคนล้วนมีร้านเวทมนตร์อยู่ในใจ ที่วงดังอย่าง BTS ก็อ่าน!! เรื่องของเด็กชายที่เดินเข้าร้านมายากลในวันที่มืดแปดด้าน
          </Text>
        </View>

       
        <View style={styles.rowContainer}>
          <TouchableOpacity onPress={handleHeartClick} style={styles.heartIcon}>
            <Ionicons
              name={heartClicked ? "heart" : "heart"}
              size={40}
              color={heartClicked ? "red" : "grey"}
            />
          </TouchableOpacity>
          <TouchableOpacity style={styles.AddButton}>
            <Text style={styles.buttonText}>Add to Cart</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    
  },
  header: {
    justifyContent: 'center',
    alignItems: 'center',
    
  },
  content: {
    flex: 1,
    paddingTop: 20,
    padding: 10,
  },
  profileName: {
    fontSize: 19,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  price: {
    color:'red',
    fontSize: 20,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  iconContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  contactInfo: {
    fontSize: 22,
    fontWeight: 'bold',
    color: 'grey',
  },
  type: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 5,
  },
  typebox: {
    backgroundColor: "#F5EEC8",
    borderColor: 'white',
    borderWidth: 3,
    padding: 5,
    borderRadius: 100,
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 5,
    height:40
  },
  detail: {
    margin: 15,
  },
  textdetail: {
    fontSize: 16,
  },
  
  rowContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 5,
    paddingHorizontal: 0,
  },
  heartIcon: {
    color:'red',
    borderRadius: 50,
    paddingVertical:10,
    marginRight:10,
    

  },
  AddButton: {
  backgroundColor: '#419197',
  paddingVertical: 10,
  borderRadius: 50,
  flex: 1,
  
},
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    
    
  },
  typetext: {
    fontWeight: 'bold',
    color: 'dimgray',
    marginTop: 3
  },
});

export default Product1;
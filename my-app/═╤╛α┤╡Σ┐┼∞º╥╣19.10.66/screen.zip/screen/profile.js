import React from 'react';
import { StyleSheet, Text, SafeAreaView, View, StatusBar, Image, TextInput, ScrollView } from 'react-native';
import { Entypo, Octicons, AntDesign } from '@expo/vector-icons';

export default function App() {
  return (
    <View style={{ flex: 1 }}>
      <View style={styles.header}>
        <Entypo name="chevron-left" size={24} color="black" style={{ flex: 1 }} />
        <Text style={styles.headerText}>Profile</Text>
        <Entypo name="log-out" size={24} color="black" style={{ flex: 1, textAlign: 'right' }} />
      </View>
      <View style={{ flex: 1, backgroundColor: 'F2F2F2', marginTop: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', paddingLeft: 20 }}>
          <Image source={{ uri: 'https://anime.atsit.in/th/wp-content/uploads/2022/11/e0b881e0b8b2e0b8a3e0b895e0b8a3e0b8a7e0b888e0b8aae0b8ade0b89ae0b882e0b989e0b8ade0b980e0b897e0b987e0b888e0b888e0b8a3e0b8b4e0b887.jpg' }} style={{ width: 100, height: 100, borderRadius: 50 }} />
          <View>
            <Text style={{ fontWeight: '400', fontSize: 24, marginLeft: 10, marginTop: 10 }}>Liz</Text>
            <Text style={{ fontSize: 20, marginLeft: 10, color: 'gray' }}>b650XXXX@g.sut.ac.th</Text>
          </View>
        </View>
      </View>
      <ScrollView>


        <View style={{ flex: 8, marginRight: 10, marginLeft: 10, marginTop: 80 }}>
          
          <View style={styles.sectionContainer}>
            

            <View style={{ marginLeft: 20, }}>
              <Text style={{ fontWeight: '200', fontWeight: 'bold', fontSize: 20 }}>My orders</Text>

              <Text style={{ fontWeight: '300', fontSize: 18, marginTop: 10, color: 'gray' }}>Already have 5 orders</Text>
            </View>
          </View>
          <View style={styles.sectionContainer}>

            <View style={{ marginLeft: 20, }}>
              <Text style={{ fontWeight: '200', fontWeight: 'bold', fontSize: 20 }}>Shipping Addresses</Text>

              <Text style={{ fontWeight: '300', fontSize: 18, marginTop: 10, color: 'gray' }}>03 Addresses</Text>
            </View>
          </View>

          <View style={styles.sectionContainer}>

            <View style={{ marginLeft: 20, }}>
              <Text style={{ fontWeight: '200', fontWeight: 'bold', fontSize: 20 }}>Payment</Text>

              <Text style={{ fontWeight: '300', fontSize: 18, marginTop: 10, color: 'gray' }}>You have 2 cards</Text>
            </View>
          </View>

          <View style={styles.sectionContainer}>

            <View style={{ marginLeft: 20, }}>
              <Text style={{ fontWeight: '200', fontWeight: 'bold', fontSize: 20 }}>My reviews</Text>

              <Text style={{ fontWeight: '300', fontSize: 18, marginTop: 10, color: 'gray' }}>Reviews for 5 items</Text>
            </View>
          </View>


          <View style={styles.sectionContainer}>

            <View style={{ marginLeft: 20, }}>
              <Text style={{ fontWeight: '200', fontWeight: 'bold', fontSize: 20 }}>Setting</Text>

              <Text style={{ fontWeight: '300', fontSize: 18, marginTop: 10, color: 'gray' }}>Notification, Password, FAQ, Contact</Text>
            </View>
          </View>
        </View>

      </ScrollView>
      <View>
      <Text style={{ marginTop:20, }}>Setting</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  sectionContainer: {
    backgroundColor: 'white',
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    borderRadius: 20,
  },
  subSectionContainer: {
    backgroundColor: 'white',
    padding: 10,
    flexDirection: 'row',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    backgroundColor: '#F2F2F2',
    marginTop: 30,
  },
  headerText: {
    fontSize: 22,
  },
});